<?php
mail('ryanbrooks@hotmail.co.uk', 'Sample Email', 'Sample Content', 'From: example@hotmail.co.uk');